// firebase-config.js
// Firebase is optional — the app works fully without it using localStorage.
// To enable Firebase: replace the config values below with your real Firebase project credentials.
// Get them from: https://console.firebase.google.com → Project Settings → Your apps

const FIREBASE_ENABLED = false; // Set to true after filling in real credentials below

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

if (FIREBASE_ENABLED &&
    firebaseConfig.apiKey !== "YOUR_API_KEY" &&
    firebaseConfig.projectId !== "YOUR_PROJECT_ID") {
  // Dynamically import Firebase only when credentials are real
  Promise.all([
    import("https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js"),
    import("https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js"),
    import("https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js")
  ]).then(([{ initializeApp }, { getAuth, signInAnonymously }, { getFirestore, doc, setDoc, getDoc, increment }]) => {
    const app = initializeApp(firebaseConfig);
    const auth = getAuth(app);
    const db = getFirestore(app);
    window.firebaseAuth = auth;
    window.firebaseDB = db;
    window.firebaseFns = { signInAnonymously, doc, setDoc, getDoc, increment };
    window.dispatchEvent(new Event('firebaseReady'));
    console.log("[PhishGuard] Firebase initialized.");
  }).catch(err => {
    console.warn("[PhishGuard] Firebase failed to load, running in offline mode.", err);
  });
} else {
  console.log("[PhishGuard] Running in offline mode (localStorage only). To enable Firebase, set FIREBASE_ENABLED=true and add real credentials.");
}
