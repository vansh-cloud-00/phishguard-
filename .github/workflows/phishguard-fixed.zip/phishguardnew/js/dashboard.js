// =============================================
//   PhishGuard – dashboard.js
//   All stats from localStorage
// =============================================

document.addEventListener('DOMContentLoaded', () => {
  const S = window.PhishGuard ? window.PhishGuard.Store : {
    get: (k, d) => { try { const v = localStorage.getItem('phishguard_' + k); return v !== null ? JSON.parse(v) : d; } catch { return d; } }
  };

  // Pull stats
  const quizzesCompleted = S.get('quizzes_completed', 0);
  const bestScore        = S.get('best_quiz_score', 0);
  const lastScore        = S.get('last_quiz_score', null);
  const lastQuizDate     = S.get('last_quiz_date', '—');
  const threatChecks     = S.get('threat_checks', 0);
  const learnVisits      = S.get('learn_visits', 0);
  const pageVisits       = S.get('page_visits', 0);

  // Awareness level calculation
  let awareness = 0;
  if (quizzesCompleted > 0) awareness += 30;
  if (bestScore >= 75)      awareness += 30;
  if (bestScore >= 90)      awareness += 10;
  if (learnVisits > 0)      awareness += 20;
  if (threatChecks > 0)     awareness += 10;
  awareness = Math.min(awareness, 100);

  // Animate counters
  function animNum(id, val, suffix='') {
    const el = document.getElementById(id);
    if (!el) return;
    if (val === 0) { el.textContent = '0' + suffix; return; }
    let start = null;
    const step = ts => {
      if (!start) start = ts;
      const p = Math.min((ts - start) / 1000, 1);
      el.textContent = Math.floor(p * val) + suffix;
      if (p < 1) requestAnimationFrame(step);
      else el.textContent = val + suffix;
    };
    setTimeout(() => requestAnimationFrame(step), 400);
  }

  animNum('stat-quizzes', quizzesCompleted);
  animNum('stat-score', bestScore, '%');
  animNum('stat-threats', threatChecks);
  animNum('stat-awareness', awareness, '%');
  animNum('stat-learns', learnVisits);
  animNum('stat-visits', pageVisits);

  // Awareness bar
  setTimeout(() => {
    const bar = document.getElementById('awareness-bar');
    if (bar) bar.style.width = awareness + '%';
  }, 600);

  // Last quiz date
  const ldEl = document.getElementById('last-quiz-date');
  if (ldEl) ldEl.textContent = lastQuizDate;

  // Last score badge
  const lsEl = document.getElementById('last-quiz-score');
  if (lsEl && lastScore !== null) {
    lsEl.textContent = lastScore + '%';
    lsEl.style.color = lastScore >= 75 ? 'var(--accent-green)' : lastScore >= 50 ? 'var(--accent-orange)' : 'var(--accent-red)';
  }

  // Status message
  const statusEl = document.getElementById('awareness-status');
  if (statusEl) {
    if (awareness === 0) statusEl.textContent = 'Start learning and take a quiz to build your score!';
    else if (awareness < 40) statusEl.textContent = 'Good start! Visit the Learn section and take a quiz.';
    else if (awareness < 70) statusEl.textContent = 'Decent awareness. Aim for 90%+ on the quiz!';
    else if (awareness < 90) statusEl.textContent = 'Strong awareness! Check Threat Intel for full marks.';
    else statusEl.textContent = '🏆 Excellent! You are a PhishGuard champion!';
  }

  // Mini activity chart (bar chart using divs)
  const chartEl = document.getElementById('activity-chart');
  if (chartEl) {
    const activities = [
      { label: 'Quizzes', val: quizzesCompleted, max: 10, color: 'var(--accent-cyan)' },
      { label: 'Learn Visits', val: learnVisits, max: 20, color: 'var(--accent-green)' },
      { label: 'Threat Checks', val: threatChecks, max: 20, color: 'var(--accent-orange)' },
      { label: 'Page Visits', val: pageVisits, max: 50, color: 'var(--accent-purple)' },
    ];

    chartEl.innerHTML = activities.map(a => {
      const pct = Math.min((a.val / a.max) * 100, 100);
      return `
        <div class="chart-bar-wrap">
          <div class="chart-bar-label">${a.label}</div>
          <div class="chart-bar-track">
            <div class="chart-bar-fill" style="width:${pct}%;background:${a.color};box-shadow:0 0 8px ${a.color};" data-target="${pct}"></div>
          </div>
          <div class="chart-bar-val" style="color:${a.color}">${a.val}</div>
        </div>
      `;
    }).join('');

    // Animate bars
    setTimeout(() => {
      document.querySelectorAll('.chart-bar-fill').forEach(b => {
        b.style.transition = 'width 1s cubic-bezier(0.4,0,0.2,1)';
      });
    }, 100);
  }

  // Badge system
  const badges = [
    { id: 'badge-first-quiz', label: 'First Quiz', icon: '🎮', earned: quizzesCompleted >= 1 },
    { id: 'badge-perfect', label: 'Perfect Score', icon: '💯', earned: bestScore === 100 },
    { id: 'badge-learner', label: 'Learner', icon: '📚', earned: learnVisits >= 1 },
    { id: 'badge-analyst', label: 'Threat Analyst', icon: '🔍', earned: threatChecks >= 1 },
    { id: 'badge-pro', label: 'Cyber Pro', icon: '🏆', earned: bestScore >= 90 },
    { id: 'badge-explorer', label: 'Explorer', icon: '🌐', earned: pageVisits >= 5 },
  ];

  const badgeEl = document.getElementById('badge-grid');
  if (badgeEl) {
    badgeEl.innerHTML = badges.map(b => `
      <div class="badge-item ${b.earned ? 'earned' : 'locked'}">
        <div class="badge-icon">${b.icon}</div>
        <div class="badge-name">${b.label}</div>
        <div class="badge-status">${b.earned ? '✓ Earned' : '🔒 Locked'}</div>
      </div>
    `).join('');
  }
});
