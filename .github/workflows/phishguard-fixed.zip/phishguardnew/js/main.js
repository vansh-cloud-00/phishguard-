// =============================================
//   PhishGuard – main.js
//   Shared utilities: nav, animations, helpers
// =============================================

// ---------- NAV ACTIVE LINK ----------
(function setActiveNav() {
  const links = document.querySelectorAll('.nav-links a');
  const current = location.pathname.split('/').pop() || 'index.html';
  links.forEach(a => {
    const href = a.getAttribute('href');
    if (href === current) a.classList.add('active');
  });
})();

// ---------- HAMBURGER MENU ----------
const hamburger = document.querySelector('.hamburger');
const navLinks  = document.querySelector('.nav-links');
if (hamburger) {
  hamburger.addEventListener('click', () => {
    navLinks.classList.toggle('open');
  });
}

// ---------- INTERSECTION OBSERVER (fade-in) ----------
const fadeEls = document.querySelectorAll('.fade-in');
const observer = new IntersectionObserver((entries) => {
  entries.forEach((e, i) => {
    if (e.isIntersecting) {
      setTimeout(() => e.target.classList.add('visible'), i * 100);
      observer.unobserve(e.target);
    }
  });
}, { threshold: 0.12 });
fadeEls.forEach(el => observer.observe(el));

// // ---------- LIVE CLOCK ----------
// const clocks = document.querySelectorAll('.live-clock');
// if (clocks.length) {
//   function tick() {
//     const now = new Date();
//     const str = now.toISOString().replace('T',' ').slice(0,19) + ' UTC';
//     clocks.forEach(c => c.textContent = str);
//   }
//   tick(); setInterval(tick, 1000);
// }

// ---------- COUNTER ANIMATION ----------
function animateCounter(el, target, duration = 1200) {
  let start = null;
  const step = ts => {
    if (!start) start = ts;
    const pct = Math.min((ts - start) / duration, 1);
    el.textContent = Math.floor(pct * target);
    if (pct < 1) requestAnimationFrame(step);
    else el.textContent = target;
  };
  requestAnimationFrame(step);
}

// ---------- STORAGE HELPERS ----------
const Store = {
  get: (k, def = null) => {
    try { const v = localStorage.getItem('phishguard_' + k); return v !== null ? JSON.parse(v) : def; }
    catch { return def; }
  },
  set: (k, v) => {
    try { localStorage.setItem('phishguard_' + k, JSON.stringify(v)); } catch {}
  },
  inc: (k) => {
    const n = Store.get(k, 0); Store.set(k, n + 1); return n + 1;
  }
};

// ---------- TYPEWRITER EFFECT ----------
function typewriter(el, text, speed = 40) {
  let i = 0; el.textContent = '';
  const timer = setInterval(() => {
    el.textContent += text[i++];
    if (i >= text.length) clearInterval(timer);
  }, speed);
}

// Track page visit
Store.inc('page_visits');

// Expose helpers globally
window.PhishGuard = { Store, animateCounter, typewriter };
