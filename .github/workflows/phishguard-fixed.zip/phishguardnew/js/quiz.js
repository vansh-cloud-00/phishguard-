// =============================================
//   PhishGuard – quiz.js
//   Interactive phishing awareness quiz
// =============================================

const QUESTIONS = [
  {
    id: 1,
    type: 'url',
    question: 'You receive an email with this link. Is it safe to click?',
    scenario: 'https://paypa1.com/secure-login/verify',
    options: ['✅ Safe – looks like PayPal', '🚨 Phishing – suspicious URL'],
    correct: 1,
    explanation: 'The URL uses "paypa1" (with the number 1) instead of "paypal". This is a classic character substitution trick. Never click this!'
  },
  {
    id: 2,
    type: 'email',
    question: 'You get this SMS from "HDFC-BANK". What do you do?',
    scenario: 'HDFC-BANK: Suspicious login detected. Share your OTP 847291 with our agent to secure your account: +91-9876543210',
    options: ['📞 Call the number and share OTP', '🚨 Ignore – real banks never ask for OTPs'],
    correct: 1,
    explanation: 'Real banks NEVER ask you to share OTPs with agents over phone or SMS. This is a smishing attack. Sharing the OTP gives the attacker access to your account.'
  },
  {
    id: 3,
    type: 'url',
    question: 'Which URL is the legitimate Google login page?',
    scenario: null,
    options: ['https://accounts.google.com', 'https://google-accounts-login.info/signin'],
    correct: 0,
    explanation: '"accounts.google.com" is the real Google login. The second URL uses "google" as a word in a completely different domain (google-accounts-login.info) — it is a phishing site.'
  },
  {
    id: 4,
    type: 'scenario',
    question: 'Your "CEO" emails you urgently to transfer ₹5 lakhs to a new vendor. The email looks official. What do you do?',
    scenario: 'From: ceo@company-secure-mail.com\nSubject: URGENT – Wire Transfer Needed Immediately\n\n"Please process ₹5,00,000 to the attached account. This is confidential. Do not discuss with others."',
    options: ['💸 Transfer immediately – CEO said so', '📞 Verify by calling CEO directly first'],
    correct: 1,
    explanation: 'This is a "CEO Fraud" or Whaling attack. The email domain is fake (company-secure-mail.com). Always verify unusual financial requests via a direct phone call to the person. The "confidential" instruction is a red flag designed to prevent you from checking.'
  },
  {
    id: 5,
    type: 'url',
    question: 'Which of these links is safe to click for SBI internet banking?',
    scenario: null,
    options: ['https://sbi-verify-account.xyz/login', 'https://www.onlinesbi.sbi'],
    correct: 1,
    explanation: 'The official SBI internet banking URL is onlinesbi.sbi. The first URL uses a .xyz TLD and contains extra words like "verify-account" — a classic phishing URL pattern.'
  },
  {
    id: 6,
    type: 'scenario',
    question: 'You receive a WhatsApp message: "Congratulations! You\'ve won an iPhone 15. Click to claim in 10 minutes!"',
    scenario: 'Message from unknown number:\n🎉 CONGRATULATIONS! You\'ve been selected!\n\nClaim your FREE iPhone 15 Pro now:\nhttp://bit.ly/win-iphone-prize\n\n⏰ Expires in 10 minutes!',
    options: ['🎁 Click quickly before it expires!', '🚫 Delete – this is a prize scam'],
    correct: 1,
    explanation: 'This is a prize phishing scam. Red flags: unknown sender, too-good-to-be-true prize, extreme urgency (10 minutes), shortened URL (bit.ly hides the real destination). These links typically steal your personal info or install malware.'
  },
  {
    id: 7,
    type: 'email',
    question: 'This email asks you to update your password. Is it legitimate?',
    scenario: 'From: security@goog1e-accounts.com\nSubject: [ACTION REQUIRED] Unusual sign-in activity\n\nDear Customer,\nWe detected unusual activity. Please update your password immediately or your account will be permanently deleted in 24 hours.\n\n[UPDATE PASSWORD NOW]',
    options: ['🔐 Update password – account at risk', '🚨 Phishing – fake Google email'],
    correct: 1,
    explanation: 'Multiple red flags: The domain is "goog1e-accounts.com" (number 1 instead of L), generic greeting "Dear Customer" instead of your name, threatening language about permanent deletion, and extreme urgency — all classic phishing tactics.'
  },
  {
    id: 8,
    type: 'url',
    question: 'A friend sends you this link. What do you check first?',
    scenario: 'http://amazon-big-sale-india.tk/deals/checkout',
    options: ['🛒 Open it – Amazon has great sales!', '🔍 Check the domain – this is not Amazon'],
    correct: 1,
    explanation: 'The real Amazon India URL is amazon.in or amazon.com. This URL uses .tk (a free TLD popular with scammers) and puts "amazon" as a word in a fake domain. Also note HTTP (not HTTPS) — no secure connection. Never enter payment info here.'
  }
];

let currentQ = 0;
let score = 0;
let answers = [];
let quizStarted = false;

const quizStart     = document.getElementById('quiz-start');
const quizQuestion  = document.getElementById('quiz-question');
const quizResult    = document.getElementById('quiz-result');

function startQuiz() {
  currentQ = 0; score = 0; answers = [];
  quizStarted = true;
  quizStart.style.display = 'none';
  quizResult.style.display = 'none';
  quizQuestion.style.display = 'block';
  renderQuestion();
  if (window.PhishGuard) PhishGuard.Store.inc('quizzes_started');
}

function renderQuestion() {
  const q = QUESTIONS[currentQ];
  const total = QUESTIONS.length;

  document.getElementById('q-progress-text').textContent = `Question ${currentQ+1} of ${total}`;
  document.getElementById('q-progress-fill').style.width = `${((currentQ)/total)*100}%`;
  document.getElementById('q-number').textContent = `Q${currentQ+1}`;
  document.getElementById('q-type').textContent = q.type.toUpperCase();
  document.getElementById('q-text').textContent = q.question;

  const scenarioEl = document.getElementById('q-scenario');
  if (q.scenario) {
    scenarioEl.style.display = 'block';
    scenarioEl.textContent = q.scenario;
  } else {
    scenarioEl.style.display = 'none';
  }

  const optsEl = document.getElementById('q-options');
  optsEl.innerHTML = '';
  q.options.forEach((opt, i) => {
    const btn = document.createElement('button');
    btn.className = 'option-btn';
    btn.textContent = opt;
    btn.addEventListener('click', () => selectAnswer(i));
    optsEl.appendChild(btn);
  });

  document.getElementById('q-feedback').style.display = 'none';
  document.getElementById('q-next').style.display = 'none';
}

function selectAnswer(idx) {
  const q = QUESTIONS[currentQ];
  const isCorrect = idx === q.correct;
  if (isCorrect) score++;
  answers.push({ question: q.question, selected: idx, correct: q.correct, isCorrect });

  const opts = document.querySelectorAll('.option-btn');
  opts.forEach((btn, i) => {
    btn.disabled = true;
    if (i === q.correct) btn.classList.add('correct');
    else if (i === idx && !isCorrect) btn.classList.add('wrong');
  });

  const feedbackEl = document.getElementById('q-feedback');
  feedbackEl.style.display = 'block';
  feedbackEl.className = 'feedback-box ' + (isCorrect ? 'feedback-correct' : 'feedback-wrong');
  feedbackEl.innerHTML = `
    <strong>${isCorrect ? '✅ Correct!' : '❌ Incorrect!'}</strong><br>
    ${q.explanation}
  `;

  document.getElementById('q-next').style.display = 'block';
}

function nextQuestion() {
  currentQ++;
  if (currentQ < QUESTIONS.length) {
    renderQuestion();
  } else {
    showResult();
  }
}

function showResult() {
  quizQuestion.style.display = 'none';
  quizResult.style.display = 'block';

  const pct = Math.round((score / QUESTIONS.length) * 100);
  let grade, gradeClass, msg;

  if (pct >= 90) { grade = 'CYBER EXPERT 🏆'; gradeClass = 'grade-gold'; msg = "Outstanding! You have excellent phishing awareness. You're equipped to protect yourself and others."; }
  else if (pct >= 75) { grade = 'SECURITY AWARE 🛡'; gradeClass = 'grade-cyan'; msg = "Great job! You know most phishing tactics. Review the ones you missed to become a full expert."; }
  else if (pct >= 50) { grade = 'LEARNING 📚'; gradeClass = 'grade-orange'; msg = "You're on the right track! Phishing attacks are tricky. Review the Learn section and try again."; }
  else { grade = 'AT RISK ⚠️'; gradeClass = 'grade-red'; msg = "You need more training. Attackers could potentially trick you. Please review the Learn section carefully."; }

  document.getElementById('r-score').textContent = score;
  document.getElementById('r-total').textContent = QUESTIONS.length;
  document.getElementById('r-pct').textContent = pct + '%';
  document.getElementById('r-grade').textContent = grade;
  document.getElementById('r-grade').className = 'result-grade ' + gradeClass;
  document.getElementById('r-msg').textContent = msg;

  // Score circle fill
  const circle = document.getElementById('r-circle');
  const circumference = 2 * Math.PI * 54;
  setTimeout(() => {
    circle.style.strokeDashoffset = circumference - (pct / 100) * circumference;
  }, 200);

  // Save to storage
  if (window.PhishGuard) {
    const prev = PhishGuard.Store.get('best_quiz_score', 0);
    if (pct > prev) PhishGuard.Store.set('best_quiz_score', pct);
    PhishGuard.Store.inc('quizzes_completed');
    PhishGuard.Store.set('last_quiz_score', pct);
    PhishGuard.Store.set('last_quiz_date', new Date().toLocaleDateString());
  }
}

function retryQuiz() { startQuiz(); }

// Expose to HTML
window.startQuiz = startQuiz;
window.nextQuestion = nextQuestion;
window.retryQuiz = retryQuiz;
